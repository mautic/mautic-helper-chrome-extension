﻿//kango.ui.browserButton.setPopup({url:'popup.html', width: 600, height:520})
//kango.ui.browserButton.setPopup(null)