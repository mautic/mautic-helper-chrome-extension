function mytrim(str){
	if (typeof str !== 'string') return str;
	return str.replace(/\/*$/, '');
}

function reset() {
	$('div.loading').hide();
	// On open, clear unread item count
	kango.storage.setItem('itemCount', 0) ;
	kango.dispatchMessage('SetItemCount', 0);
}

KangoAPI.onReady(function() {

	var refresh = kango.storage.getItem('refresh');
	var url = mytrim(kango.storage.getItem('url'));
	var enabl = kango.storage.getItem('enable');
	var itemCount = kango.storage.getItem('itemCount');

	$('div.loading').show();

	document.getElementById('timeline_frame').src = url + '/s/plugin/Gmail/timeline?count=' + itemCount;

	$('iframe').load(reset);

	setTimeout(reset, 5000); // in case loading is stuck

});
