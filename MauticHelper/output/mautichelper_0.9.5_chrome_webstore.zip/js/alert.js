KangoAPI.onReady(function() {

    $('#goto').click(function(){
    	kango.ui.optionsPage.open();
    	KangoAPI.closeWindow();
    });

});
